/* AppController */

#import <Cocoa/Cocoa.h>
#import <HMBlkAppKit/HMBlkAppKit.h>

@interface AppController : NSObject
{
    HMBlkProgressIndicator* _progressIndicator0;
    HMBlkProgressIndicator* _progressIndicator1;
}
@end
