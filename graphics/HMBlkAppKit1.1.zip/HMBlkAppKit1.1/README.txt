The licenses of Shiira source codes and image resources are the modified BSD licenses. (http://en.wikipedia.org/wiki/BSD_license) When you use them in your product, you need to describe the following:

* "This software uses source codes and image resources copyrighted by Shiira Project."
* A link to the Shiira project web page (http://shiira.jp/)

That is all we require. You don't need to ask us our permission, or to be open your source codes. We encourage you to use the result of our project.



-----------
Copyright 2004-2007 Shiira Project, All Rights Reserved.

Programmed by Makoto Kinoshita (mkino), HMDT (http://hmdt.jp)
Designed by Kei Sasaki
